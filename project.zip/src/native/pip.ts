// Trình cài thư viện bên ngoài cho bản APK, dựa trên micropip của Pyodide.
import { PyodideRunner } from '../utils/pythonRunner';

const REQS_KEY = 'pydroid_pip_requirements';
const NAME_RE = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;
const REQ_RE =
  /^[A-Za-z0-9][A-Za-z0-9._-]*(\[[A-Za-z0-9._,-]+\])?\s*((==|>=|<=|~=|!=|>|<)\s*[A-Za-z0-9.*+!_-]+(\s*,\s*(==|>=|<=|~=|!=|>|<)\s*[A-Za-z0-9.*+!_-]+)*)?$/;

const w = window as any;
let micropipFor: any = null;
let chain: Promise<unknown> = Promise.resolve();

function enqueue<T>(fn: () => Promise<T>): Promise<T> {
  const p = chain.then(fn, fn);
  chain = p.catch(() => undefined);
  return p;
}

function loadReqs(): string[] {
  try {
    const v = JSON.parse(localStorage.getItem(REQS_KEY) || '[]');
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : [];
  } catch (_) {
    return [];
  }
}

function saveReqs(list: string[]) {
  try {
    localStorage.setItem(REQS_KEY, JSON.stringify(list));
  } catch (_) {}
}

function normName(req: string): string {
  return req.split(/[\[=<>~!\s]/)[0].toLowerCase().replace(/[-_.]+/g, '-');
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function waitForInstance(timeoutMs: number): Promise<any> {
  const start = Date.now();
  while (!w.pyodideInstance) {
    if (Date.now() - start > timeoutMs) throw new Error('Pyodide chưa sẵn sàng. Hãy thử lại sau ít phút.');
    await sleep(500);
  }
  return w.pyodideInstance;
}

async function getPyodide(): Promise<any> {
  if (!w.pyodideInstance) {
    try {
      await new PyodideRunner().warmup();
    } catch (_) {}
  }
  return waitForInstance(120000);
}

async function ensureMicropip(py: any) {
  if (micropipFor === py) return;
  await py.loadPackage('micropip');
  micropipFor = py;
}

function shortError(e: any): string {
  const msg = String(e?.message || e || 'Lỗi không rõ');
  const lines = msg.split('\n').filter((l) => l.trim());
  return lines.slice(-4).join('\n');
}

export function parseRequirements(raw: string): string[] {
  const text = (raw || '').trim();
  if (!text) return [];
  const hasOperator = /[=<>~!]/.test(text);
  return hasOperator ? [text] : text.split(/[\s,]+/).filter(Boolean);
}

export function pipInstall(raw: string, upgrade: boolean) {
  return enqueue(async () => {
    const reqs = parseRequirements(raw);
    if (reqs.length === 0) return { success: false, output: '', error: 'Tên thư viện trống.' };
    for (const r of reqs) {
      if (!REQ_RE.test(r)) {
        const msg = `Tên thư viện không hợp lệ: ${r}`;
        return { success: false, output: `❌ ${msg}`, error: msg };
      }
    }
    let out = '';
    let allOk = true;
    try {
      const py = await getPyodide();
      out += '⏳ Đang chuẩn bị trình cài đặt (micropip)...\n';
      await ensureMicropip(py);
      const saved = loadReqs();
      for (const req of reqs) {
        out += `📦 Đang cài ${req}...\n`;
        try {
          py.globals.set('__pip_req', req);
          py.globals.set('__pip_upgrade', !!upgrade);
          await py.runPythonAsync(
            'import micropip, importlib\nawait micropip.install(__pip_req, reinstall=__pip_upgrade)\nimportlib.invalidate_caches()'
          );
          out += `✅ Đã cài xong ${req}\n`;
          const n = normName(req);
          const idx = saved.findIndex((s) => normName(s) === n);
          if (idx >= 0) saved[idx] = req;
          else saved.push(req);
        } catch (e) {
          allOk = false;
          out +=
            `❌ Không cài được ${req}:\n${shortError(e)}\n` +
            'Gợi ý: chỉ cài được thư viện Python thuần hoặc thư viện có sẵn trong Pyodide, và cần có mạng.\n';
        }
      }
      saveReqs(saved);
    } catch (e) {
      allOk = false;
      out += `❌ ${shortError(e)}\n`;
    }
    return { success: allOk, output: out, error: allOk ? undefined : 'Cài đặt thất bại' };
  });
}

export function pipUninstall(raw: string) {
  return enqueue(async () => {
    const name = (raw || '').trim();
    if (!NAME_RE.test(name)) {
      return { success: false, output: '❌ Tên thư viện không hợp lệ.', error: 'Tên không hợp lệ' };
    }
    try {
      const py = await getPyodide();
      await ensureMicropip(py);
      py.globals.set('__pip_name', name);
      await py.runPythonAsync(
        'import micropip, inspect, importlib\nr = micropip.uninstall(__pip_name)\nif inspect.isawaitable(r):\n    await r\nimportlib.invalidate_caches()'
      );
      const n = normName(name);
      saveReqs(loadReqs().filter((s) => normName(s) !== n));
      return { success: true, output: `🗑️ Đã gỡ ${name} thành công.\n` };
    } catch (e) {
      return { success: false, output: `❌ Không gỡ được ${name}:\n${shortError(e)}\n`, error: 'Gỡ bỏ thất bại' };
    }
  });
}

export async function pipList(): Promise<{ name: string; version: string }[]> {
  const py = w.pyodideInstance;
  if (py && micropipFor === py) {
    try {
      const res = await py.runPythonAsync(
        'import micropip, json\njson.dumps([{"name": p.name, "version": p.version} for p in micropip.list().values()])'
      );
      const arr = JSON.parse(String(res));
      if (Array.isArray(arr)) {
        return arr.sort((a: any, b: any) => String(a.name).localeCompare(String(b.name)));
      }
    } catch (_) {}
  }
  return loadReqs().map((r) => ({ name: normName(r), version: 'đã cài' }));
}

const POPULAR: { name: string; summary: string }[] = [
  { name: 'requests', summary: 'Gửi yêu cầu HTTP đơn giản' },
  { name: 'beautifulsoup4', summary: 'Phân tích HTML/XML' },
  { name: 'numpy', summary: 'Tính toán số học, mảng nhiều chiều' },
  { name: 'pandas', summary: 'Phân tích và xử lý dữ liệu dạng bảng' },
  { name: 'matplotlib', summary: 'Vẽ biểu đồ' },
  { name: 'scipy', summary: 'Tính toán khoa học' },
  { name: 'sympy', summary: 'Toán học ký hiệu' },
  { name: 'pillow', summary: 'Xử lý hình ảnh' },
  { name: 'pyyaml', summary: 'Đọc/ghi tệp YAML' },
  { name: 'python-dateutil', summary: 'Mở rộng xử lý ngày giờ' },
  { name: 'rich', summary: 'In terminal đẹp, có màu' },
  { name: 'colorama', summary: 'Chữ màu trên terminal' },
  { name: 'tabulate', summary: 'In bảng dạng chữ' },
  { name: 'attrs', summary: 'Khai báo lớp dữ liệu gọn' },
  { name: 'pydantic', summary: 'Kiểm tra và chuẩn hóa dữ liệu' },
  { name: 'networkx', summary: 'Đồ thị và mạng' },
  { name: 'scikit-learn', summary: 'Học máy' },
  { name: 'regex', summary: 'Biểu thức chính quy nâng cao' },
];

export async function pipSearch(q: string): Promise<{ name: string; summary: string; version?: string }[]> {
  const query = (q || '').trim().toLowerCase();
  if (!query) return POPULAR;
  const results: { name: string; summary: string; version?: string }[] = POPULAR.filter(
    (p) => p.name.includes(query) || p.summary.toLowerCase().includes(query)
  );
  if (NAME_RE.test(query)) {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      const res = await fetch(`https://pypi.org/pypi/${encodeURIComponent(query)}/json`, {
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (res.ok) {
        const data = await res.json();
        const info = data?.info;
        if (info?.name && !results.some((r) => normName(r.name) === normName(info.name))) {
          results.unshift({ name: info.name, summary: info.summary || '', version: info.version });
        }
      }
    } catch (_) {}
  }
  return results;
}

// Khôi phục các thư viện đã cài sau khi mở lại ứng dụng (cần mạng)
w.__pydroidPipReady = (async () => {
  if (loadReqs().length === 0) return;
  try {
    await Promise.race([
      enqueue(async () => {
        const py = await waitForInstance(10 * 60 * 1000);
        await ensureMicropip(py);
        for (const req of loadReqs()) {
          try {
            py.globals.set('__pip_req', req);
            await py.runPythonAsync(
              'import micropip, importlib\nawait micropip.install(__pip_req)\nimportlib.invalidate_caches()'
            );
          } catch (_) {}
        }
      }),
      sleep(10 * 60 * 1000 + 120000),
    ]);
  } catch (_) {}
})();
