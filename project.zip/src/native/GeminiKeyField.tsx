import { useState } from 'react';
import { GEMINI_KEY_STORAGE } from './apiShim';

export default function GeminiKeyField() {
  const [value, setValue] = useState<string>(() => {
    try {
      return localStorage.getItem(GEMINI_KEY_STORAGE) || '';
    } catch (_) {
      return '';
    }
  });
  const [saved, setSaved] = useState(false);

  const save = () => {
    try {
      const v = value.trim();
      if (v) localStorage.setItem(GEMINI_KEY_STORAGE, v);
      else localStorage.removeItem(GEMINI_KEY_STORAGE);
      setSaved(true);
      setTimeout(() => setSaved(false), 1800);
    } catch (_) {}
  };

  return (
    <div className="p-2.5 rounded-xl bg-[#141420] border border-[#262538]">
      <div className="font-semibold text-gray-200 mb-1.5">🔑 Khóa Gemini API (cho tính năng AI)</div>
      <div className="flex space-x-1.5">
        <input
          type="password"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Dán khóa API vào đây"
          autoComplete="off"
          className="flex-1 min-w-0 bg-[#0e0e18] border border-[#2c2b42] rounded-lg px-2 py-1.5 text-gray-100 text-xs outline-none"
        />
        <button
          onClick={save}
          className="px-3 py-1.5 rounded-lg bg-amber-400/20 border border-amber-400/40 text-amber-300 font-bold text-xs cursor-pointer"
        >
          {saved ? 'Đã lưu' : 'Lưu'}
        </button>
      </div>
      <div className="text-[10px] text-gray-500 mt-1">
        Khóa chỉ lưu trên điện thoại của bạn. Không có khóa, ứng dụng dùng bộ phân tích cục bộ.
      </div>
    </div>
  );
}
