// Các hàm phân tích/sửa lỗi cục bộ (không cần máy chủ) - trích từ server.ts gốc.
/* eslint-disable */
function ensureVietnameseLessonQuality(lesson: any) {
  let { starterCode = '', solutionCode = '' } = lesson;

  // Replace common English variable leaks with clear Vietnamese names
  const varMap: Record<string, string> = {
    '\\btotal\\b': 'tong_so',
    '\\bresult\\b': 'ket_qua',
    '\\bdata\\b': 'du_lieu',
    '\\bitems\\b': 'danh_sach_muc',
    '\\bitem\\b': 'phan_tu',
    '\\bcount\\b': 'so_luong',
    '\\btemp\\b': 'bien_tam',
    '\\bnumbers\\b': 'danh_sach_so',
    '\\buser_num\\b': 'so_nguoi_chon',
    '\\bchosen\\b': 'so_da_chon',
    '\\bdie1\\b': 'xuc_xac_1',
    '\\bdie2\\b': 'xuc_xac_2',
    '\\bmy_func\\b': 'ham_xu_ly',
    '\\bprocess_data\\b': 'xu_ly_du_lieu',
    '\\bfiltered\\b': 'danh_sach_loc',
    '\\boutput\\b': 'dau_ra',
    '\\binput_val\\b': 'gia_tri_nhap',
    '\\barr\\b': 'mang_so',
    '\\blst\\b': 'danh_sach',
  };

  for (const [pattern, replacement] of Object.entries(varMap)) {
    const re = new RegExp(pattern, 'g');
    starterCode = starterCode.replace(re, replacement);
    solutionCode = solutionCode.replace(re, replacement);
  }

  const rawLvl = String(lesson.level || '').toLowerCase().trim();
  const normalizedLevel = (rawLvl.includes('nâng') || rawLvl.includes('nang') || rawLvl.includes('adv') || rawLvl.includes('hard') || rawLvl.includes('3'))
    ? 'advanced'
    : (rawLvl.includes('trung') || rawLvl.includes('inter') || rawLvl.includes('vừa') || rawLvl.includes('2'))
    ? 'intermediate'
    : 'basic';

  const safeId = lesson.id && typeof lesson.id === 'string' && lesson.id.startsWith('lesson_') && !lesson.id.includes('undefined')
    ? `${lesson.id}_${Date.now().toString(36)}`
    : `lesson_ai_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  return {
    ...lesson,
    id: safeId,
    title: String(lesson.title || 'Bài tập thực hành Python mới').trim(),
    level: normalizedLevel,
    description: String(lesson.description || '').trim(),
    starterCode: String(starterCode || '').trim(),
    solutionCode: String(solutionCode || '').trim(),
    explanation: String(lesson.explanation || 'Thuật toán được tối ưu chuẩn PEP 8 với 100% tên biến tiếng Việt.').trim(),
    sampleInput: lesson.sampleInput || '',
    sampleOutput: lesson.sampleOutput || '',
    completed: false,
  };
}

// Helper to generate smart fallback lessons if Gemini API is under high demand (503)
// Rich Dynamic Fallback Lesson Generator (100% Vietnamese variables, guarantees unique titles)
function getFallbackLessons(topic: string, levelStr: string, existingTitles: string[] = []) {
  const normTopic = topic.toLowerCase().trim();
  const level = (levelStr === 'nâng cao' ? 'advanced' : levelStr === 'trung cấp' ? 'intermediate' : 'basic') as 'basic' | 'intermediate' | 'advanced';
  const ts = Date.now().toString(36);
  const titlesSet = new Set(existingTitles.map((t) => t.toLowerCase().trim()));

  const makeUniqueTitle = (baseTitle: string) => {
    let t = baseTitle;
    let cnt = 1;
    while (titlesSet.has(t.toLowerCase().trim())) {
      cnt++;
      t = `${baseTitle} (Mục ${cnt})`;
    }
    titlesSet.add(t.toLowerCase().trim());
    return t;
  };

  const pool: any[] = [];

  // 1. Topic: Vòng lặp / Loop
  if (normTopic.includes('vòng lặp') || normTopic.includes('loop') || normTopic.includes('for') || normTopic.includes('while')) {
    pool.push({
      id: `lesson_cuu_chuong_${ts}`,
      title: makeUniqueTitle(`Thực hành: Bảng cửu chương tuần hoàn (${topic})`),
      level,
      description: 'Nhập số nguyên dương n (từ 1 đến 9). Sử dụng vòng lặp for để in ra bảng cửu chương tương ứng với định dạng n x i = ket_qua.',
      starterCode: `# Nhập số cần in bảng nhân\nso_nhan = int(input("Nhập số bảng cửu chương (1-9): "))\n\n# TODO: Dùng vòng lặp for để in bảng nhân từ 1 đến 10\nfor chi_so in range(1, 11):\n    tich_so = so_nhan * chi_so\n    print(f"{so_nhan} x {chi_so} = {tich_so}")\n`,
      solutionCode: `def in_bang_cuu_chuong(con_so: int) -> None:\n    for thu_tu in range(1, 11):\n        ket_qua_nhan = con_so * thu_tu\n        print(f"{con_so} x {thu_tu} = {ket_qua_nhan}")\n\nif __name__ == "__main__":\n    so_can_in = int(input("Bảng cửu chương số: "))\n    in_bang_cuu_chuong(so_can_in)\n`,
      explanation: 'Vòng lặp for kết hợp với hàm range(1, 11) giúp lặp chính xác 10 lần từ 1 đến 10 theo đúng chuẩn mực PEP 8.',
      sampleInput: '7\n',
      sampleOutput: '7 x 1 = 7\n7 x 2 = 14\n...\n7 x 10 = 70\n',
    });
    pool.push({
      id: `lesson_tong_le_${ts}`,
      title: makeUniqueTitle(`Thực hành: Tính tổng các số lẻ liên tiếp (${topic})`),
      level,
      description: 'Nhập vào số nguyên dương n. Sử dụng vòng lặp tính tổng tất cả các số lẻ từ 1 đến n và in ra màn hình.',
      starterCode: `gioi_han_n = int(input("Nhập số n: "))\n\n# TODO: Tính tổng các số lẻ từ 1 đến n\ntong_so_le = 0\nfor so_hien_tai in range(1, gioi_han_n + 1):\n    if so_hien_tai % 2 != 0:\n        tong_so_le += so_hien_tai\n\nprint(f"Tổng các số lẻ từ 1 đến {gioi_han_n} là: {tong_so_le}")\n`,
      solutionCode: `def tinh_tong_so_le(gioi_han: int) -> int:\n    tong_tich_luy = sum(so for so in range(1, gioi_han + 1) if so % 2 != 0)\n    return tong_tich_luy\n\nif __name__ == "__main__":\n    so_n = int(input("Nhập n: "))\n    dap_an = tinh_tong_so_le(so_n)\n    print(f"Tổng số lẻ: {dap_an}")\n`,
      explanation: 'Toán tử chia lấy dư % 2 != 0 giúp kiểm tra tính chẵn lẻ của số nguyên nhanh chóng.',
      sampleInput: '9\n',
      sampleOutput: 'Tổng các số lẻ từ 1 đến 9 là: 25\n',
    });
  }

  // 2. Topic: Chuỗi / Xử lý văn bản
  else if (normTopic.includes('chuỗi') || normTopic.includes('string') || normTopic.includes('văn bản') || normTopic.includes('từ')) {
    pool.push({
      id: `lesson_dem_tu_${ts}`,
      title: makeUniqueTitle(`Thực hành: Đếm từ & chuẩn hoá họ tên (${topic})`),
      level,
      description: 'Nhập họ và tên người dùng có khoảng trắng thừa. Viết chương trình chuẩn hóa chuỗi (bỏ khoảng trắng thừa, viết hoa chữ cái đầu mỗi từ) và đếm tổng số từ.',
      starterCode: `ho_ten_tho = input("Nhập họ tên: ")\n\n# TODO: Chuẩn hóa họ tên\ndanh_sach_tu = ho_ten_tho.strip().split()\nho_ten_chuan = " ".join(tu.capitalize() for tu in danh_sach_tu)\nso_luong_tu = len(danh_sach_tu)\n\nprint(f"Họ tên chuẩn: {ho_ten_chuan}")\nprint(f"Số lượng từ: {so_luong_tu}")\n`,
      solutionCode: `def chuan_hoa_ho_ten(chuoi_nhap: str) -> tuple[str, int]:\n    cac_tu = chuoi_nhap.strip().split()\n    ten_chuan = " ".join(tung_tu.capitalize() for tung_tu in cac_tu)\n    return ten_chuan, len(cac_tu)\n\nif __name__ == "__main__":\n    chuoi_goc = input("Họ tên: ")\n    ten_dep, so_tu = chuan_hoa_ho_ten(chuoi_goc)\n    print(f"Tên: {ten_dep} | Số từ: {so_tu}")\n`,
      explanation: 'Phương thức split() tự động tách chuỗi theo khoảng trắng bất kỳ, kết hợp capitalize() để viết hoa chữ cái đầu.',
      sampleInput: '   nguyen   van   an   \n',
      sampleOutput: 'Họ tên chuẩn: Nguyen Van An\nSố lượng từ: 3\n',
    });
    pool.push({
      id: `lesson_nguyen_am_${ts}`,
      title: makeUniqueTitle(`Thực hành: Thống kê nguyên âm trong câu (${topic})`),
      level,
      description: 'Nhập một câu văn bản tiếng Việt không dấu. Đếm số lượng các nguyên âm (a, e, i, o, u) xuất hiện trong câu.',
      starterCode: `cau_van_ban = input("Nhập văn bản: ").lower()\nnguyen_am = "aeiou"\n\n# TODO: Đếm số nguyên âm\nso_nguyen_am = sum(1 for ky_tu in cau_van_ban if ky_tu in nguyen_am)\nprint(f"Số lượng nguyên âm: {so_nguyen_am}")\n`,
      solutionCode: `def dem_so_nguyen_am(van_ban: str) -> int:\n    tap_nguyen_am = set("aeiou")\n    return sum(1 for chu in van_ban.lower() if chu in tap_nguyen_am)\n\nif __name__ == "__main__":\n    doan_van = input("Văn bản: ")\n    print(f"Tổng nguyên âm: {dem_so_nguyen_am(doan_van)}")\n`,
      explanation: 'Sử dụng cấu trúc set() tăng tốc độ tra cứu phần tử với độ phức tạp O(1).',
      sampleInput: 'lap trinh python tren pydroid\n',
      sampleOutput: 'Số lượng nguyên âm: 7\n',
    });
  }

  // 3. Topic: Game / Trò chơi / Xúc xắc
  else if (normTopic.includes('game') || normTopic.includes('trò chơi') || normTopic.includes('xúc xắc') || normTopic.includes('đoán')) {
    pool.push({
      id: `lesson_xuc_xac_${ts}`,
      title: makeUniqueTitle(`Mini-Game: Đổ xúc xắc tính điểm thưởng (${topic})`),
      level,
      description: 'Mô phỏng gieo 2 viên xúc xắc 6 mặt (1-6). Nếu tổng điểm >= 10 hoặc 2 viên xúc xắc có cùng số điểm (xúc xắc đôi), người chơi thắng lớn!',
      starterCode: `import random\n\n# TODO: Gieo 2 viên xúc xắc\nxuc_xac_1 = random.randint(1, 6)\nxuc_xac_2 = random.randint(1, 6)\ntong_diem = xuc_xac_1 + xuc_xac_2\n\nprint(f"Viên 1: {xuc_xac_1} | Viên 2: {xuc_xac_2} -> Tổng: {tong_diem}")\nif xuc_xac_1 == xuc_xac_2:\n    print("🎉 BẠN ĐỔ ĐƯỢC XÚC XẮC ĐÔI! Thắng đậm!")\nelif tong_diem >= 10:\n    print("🏆 Xuất sắc! Điểm cao chiến thắng!")\nelse:\n    print("Chúc bạn may mắn lần sau!")\n`,
      solutionCode: `import random\n\ndef gieo_xuc_xac() -> tuple[int, int, int, str]:\n    vien_1 = random.randint(1, 6)\n    vien_2 = random.randint(1, 6)\n    tong = vien_1 + vien_2\n    if vien_1 == vien_2:\n        thong_bao = "Xúc xắc đôi thắng lớn!"\n    elif tong >= 10:\n        thong_bao = "Điểm cao thắng cuộc!"\n    else:\n        thong_bao = "Lượt chơi bình thường."\n    return vien_1, vien_2, tong, thong_bao\n\nif __name__ == "__main__":\n    v1, v2, t, tb = gieo_xuc_xac()\n    print(f"Lượt gieo: [{v1}] và [{v2}] (Tổng: {t}) -> {tb}")\n`,
      explanation: 'Module random cung cấp hàm randint() tạo số ngẫu nhiên mô phỏng trò chơi xúc xắc sinh động.',
      sampleOutput: 'Lượt gieo: [5] và [5] (Tổng: 10) -> Xúc xắc đôi thắng lớn!\n',
    });
    pool.push({
      id: `lesson_keo_bua_bao_${ts}`,
      title: makeUniqueTitle(`Mini-Game: Kéo Búa Bao đối đầu máy tính (${topic})`),
      level,
      description: 'Cho người chơi chọn Kéo, Búa hoặc Bao. Máy tính chọn ngẫu nhiên. So sánh kết quả và in ra người chiến thắng.',
      starterCode: `import random\n\ncac_lua_chon = ["kéo", "búa", "bao"]\nnguoi_chon = input("Chọn kéo, búa hoặc bao: ").lower().strip()\nmay_chon = random.choice(cac_lua_chon)\n\nprint(f"Bạn ra: {nguoi_chon} | Máy ra: {may_chon}")\nif nguoi_chon == may_chon:\n    print("Hòa nhau!")\nelif (nguoi_chon == "búa" and may_chon == "kéo") or \\\n     (nguoi_chon == "kéo" and may_chon == "bao") or \\\n     (nguoi_chon == "bao" and may_chon == "búa"):\n    print("🎉 Bạn đã chiến thắng!")\nelse:\n    print("Máy tính đã thắng!")\n`,
      solutionCode: `import random\n\ndef dau_keo_bua_bao(lua_chon_nguoi: str) -> str:\n    cac_nuoc_di = ["kéo", "búa", "bao"]\n    nuoc_di_may = random.choice(cac_nuoc_di)\n    print(f"Người: {lua_chon_nguoi} vs Máy: {nuoc_di_may}")\n    if lua_chon_nguoi == nuoc_di_may:\n        return "Hòa!"\n    thang = [("búa", "kéo"), ("kéo", "bao"), ("bao", "búa")]\n    if (lua_chon_nguoi, nuoc_di_may) in thang:\n        return "Người chơi thắng!"\n    return "Máy tính thắng!"\n\nif __name__ == "__main__":\n    nuoc_nguoi = input("Chọn: ")\n    print(dau_keo_bua_bao(nuoc_nguoi))\n`,
      explanation: 'Sử dụng danh sách các cặp bộ thắng trong tuple giúp kiểm tra điều kiện chiến thắng ngắn gọn.',
      sampleInput: 'búa\n',
      sampleOutput: 'Người: búa vs Máy: kéo\nNgười chơi thắng!\n',
    });
  }

  // 4. Default / Real-World Applications
  else {
    pool.push({
      id: `lesson_tra_sua_${ts}`,
      title: makeUniqueTitle(`Thực hành: Tính tiền hoá đơn Trà sữa (${topic})`),
      level,
      description: 'Viết chương trình tính tiền đặt hàng trà sữa. Nhập số lượng ly, đơn giá từng ly và phần trăm giảm giá khuyến mãi (nếu có). In ra tổng số tiền phải thanh toán kèm hóa đơn chi tiết.',
      starterCode: `# Nhập thông tin đơn hàng trà sữa\nso_luong_ly = int(input("Nhập số lượng ly trà sữa: "))\ndon_gia_ly = int(input("Nhập đơn vị giá mỗi ly (VNĐ): "))\nphan_tram_giam = float(input("Nhập % giảm giá (vd: 10 cho 10%): "))\n\n# TODO: Tính tổng tiền trước giảm và sau giảm\ntong_tien_goc = so_luong_ly * don_gia_ly\ntien_duoc_giam = tong_tien_goc * (phan_tram_giam / 100)\ntong_thanh_toan = tong_tien_goc - tien_duoc_giam\n\nprint(f"Tổng tiền gốc: {tong_tien_goc:,.0f} VNĐ")\nprint(f"Số tiền giảm: {tien_duoc_giam:,.0f} VNĐ")\nprint(f"Số tiền cần trả: {tong_thanh_toan:,.0f} VNĐ")\n`,
      solutionCode: `def tinh_tien_hoa_don(so_luong: int, don_gia: int, giam_gia_phan_tram: float) -> tuple[float, float, float]:\n    tong_tien_chua_giam = so_luong * don_gia\n    so_tien_giam = tong_tien_chua_giam * (giam_gia_phan_tram / 100.0)\n    tong_so_tien_phai_tra = tong_tien_chua_giam - so_tien_giam\n    return tong_tien_chua_giam, so_tien_giam, tong_so_tien_phai_tra\n\nif __name__ == "__main__":\n    so_ly = int(input("Số ly: "))\n    gia_moi_ly = int(input("Đơn giá: "))\n    muc_giam = float(input("Phần trăm giảm: "))\n    \n    tien_goc, tien_giam, thanh_toan = tinh_tien_hoa_don(so_ly, gia_moi_ly, muc_giam)\n    print(f"Hoá đơn: Gốc {tien_goc:,.0f}đ - Giảm {tien_giam:,.0f}đ = Thanh toán: {thanh_toan:,.0f}đ")\n`,
      explanation: 'Bài toán rèn luyện kỹ năng tính toán số học, định dạng số có dấu phân cách hàng nghìn (:,.0f) và đặt tên biến 100% tiếng Việt chuẩn snake_case.',
      sampleInput: '3\n35000\n10\n',
      sampleOutput: 'Hoá đơn: Gốc 105,000đ - Giảm 10,500đ = Thanh toán: 94,500đ\n',
    });
    pool.push({
      id: `lesson_chi_tieu_${ts}`,
      title: makeUniqueTitle(`Thực hành: Quản lý chi tiêu sinh hoạt (${topic})`),
      level,
      description: 'Cho danh sách các khoản chi tiêu trong tuần của sinh viên. Viết hàm tính tổng chi tiêu, tìm khoản chi tiêu lớn nhất và tính mức chi tiêu trung bình mỗi ngày.',
      starterCode: `# Danh sách các khoản chi tiêu trong tuần\ndanh_sach_chi_tieu = [45000, 120000, 60000, 250000, 80000, 30000, 95000]\n\n# TODO: Tính tổng chi tiêu và chi tiêu lớn nhất\ntong_so_tien_chi = sum(danh_sach_chi_tieu)\nkhoan_chi_lon_nhat = max(danh_sach_chi_tieu)\nchi_tieu_trung_binh = tong_so_tien_chi / len(danh_sach_chi_tieu)\n\nprint(f"Tổng chi trong tuần: {tong_so_tien_chi:,.0f} VNĐ")\nprint(f"Khoản chi nhiều nhất: {khoan_chi_lon_nhat:,.0f} VNĐ")\nprint(f"Trung bình mỗi ngày: {chi_tieu_trung_binh:,.0f} VNĐ")\n`,
      solutionCode: `def phan_tich_chi_tieu(cac_khoan_chi: list[int]) -> dict:\n    tong_chi = sum(cac_khoan_chi)\n    chi_cao_nhat = max(cac_khoan_chi) if cac_khoan_chi else 0\n    trung_binh_ngay = tong_chi / len(cac_khoan_chi) if cac_khoan_chi else 0.0\n    return {\n        "tong_tien": tong_chi,\n        "cao_nhat": chi_cao_nhat,\n        "trung_binh": trung_binh_ngay\n    }\n\nif __name__ == "__main__":\n    so_lieu_chi = [45000, 120000, 60000, 250000, 80000, 30000, 95000]\n    ket_qua_thong_ke = phan_tich_chi_tieu(so_lieu_chi)\n    print(f"Tổng chi: {ket_qua_thong_ke['tong_tien']:,}đ | Cao nhất: {ket_qua_thong_ke['cao_nhat']:,}đ")\n`,
      explanation: 'Sử dụng các hàm có sẵn sum(), max(), len() kết hợp với kiểu dữ liệu từ điển (dict) giúp cấu trúc dữ liệu tường minh, chuẩn mực.',
      sampleOutput: 'Tổng chi: 680,000đ | Cao nhất: 250,000đ\n',
    });
    pool.push({
      id: `lesson_diem_thi_${ts}`,
      title: makeUniqueTitle(`Thực hành: Thống kê & Xếp loại điểm thi (${topic})`),
      level,
      description: 'Nhập danh sách điểm thi của các môn học. Tính điểm trung bình môn, đếm số môn đạt loại Giỏi (từ 8.0 trở lên) và in kết luận xếp loại chung.',
      starterCode: `# Danh sách điểm các môn\nbang_diem_hoc_ky = [8.5, 7.0, 9.2, 6.5, 8.8, 9.0]\n\n# TODO: Tính điểm trung bình và đếm môn Giỏi (>= 8.0)\ndiem_trung_binh = sum(bang_diem_hoc_ky) / len(bang_diem_hoc_ky)\nso_mon_gioi = sum(1 for diem in bang_diem_hoc_ky if diem >= 8.0)\n\nprint(f"Điểm trung bình học kỳ: {diem_trung_binh:.2f}")\nprint(f"Số môn đạt loại Giỏi: {so_mon_gioi}")\n`,
      solutionCode: `def xep_loai_hoc_tap(danh_sach_diem: list[float]) -> tuple[float, str]:\n    diem_trung_binh_chung = sum(danh_sach_diem) / len(danh_sach_diem)\n    if diem_trung_binh_chung >= 8.0:\n        danh_hieu = "Học sinh Giỏi"\n    elif diem_trung_binh_chung >= 6.5:\n        danh_hieu = "Học sinh Khá"\n    else:\n        danh_hieu = "Học sinh Trung bình"\n    return diem_trung_binh_chung, danh_hieu\n\nif __name__ == "__main__":\n    diem_cac_mon = [8.5, 7.0, 9.2, 6.5, 8.8, 9.0]\n    diem_tb, danh_hieu = xep_loai_hoc_tap(diem_cac_mon)\n    print(f"Điểm TB: {diem_tb:.2f} -> Danh hiệu: {danh_hieu}")\n`,
      explanation: 'Vận dụng rẽ nhánh điều kiện if-elif-else kết hợp tính toán số thực (float) với độ chính xác cao.',
      sampleOutput: 'Điểm TB: 8.17 -> Danh hiệu: Học sinh Giỏi\n',
    });
    pool.push({
      id: `lesson_cuoc_xe_${ts}`,
      title: makeUniqueTitle(`Ứng dụng: Tính giá cước xe công nghệ (${topic})`),
      level,
      description: 'Xây dựng thuật toán tính tiền chuyến xe công nghệ theo quãng đường đi (km): 2 km đầu giá 20,000đ, từ km thứ 3 đến km thứ 10 giá 8,500đ/km, từ km thứ 11 trở đi giá 7,000đ/km.',
      starterCode: `so_km_di_chuyen = float(input("Nhập số km chuyến xe: "))\n\n# TODO: Tính tổng cước phí theo từng chặng\ntong_cuoc_phi = 0.0\nif so_km_di_chuyen <= 2:\n    tong_cuoc_phi = 20000.0\nelif so_km_di_chuyen <= 10:\n    tong_cuoc_phi = 20000.0 + (so_km_di_chuyen - 2) * 8500.0\nelse:\n    tong_cuoc_phi = 20000.0 + 8 * 8500.0 + (so_km_di_chuyen - 10) * 7000.0\n\nprint(f"Tổng tiền cước: {tong_cuoc_phi:,.0f} VNĐ")\n`,
      solutionCode: `def tinh_cuoc_chuyen_xe(quang_duong_km: float) -> float:\n    if quang_duong_km <= 2.0:\n        return 20000.0\n    if quang_duong_km <= 10.0:\n        return 20000.0 + (quang_duong_km - 2.0) * 8500.0\n    return 20000.0 + (8.0 * 8500.0) + (quang_duong_km - 10.0) * 7000.0\n\nif __name__ == "__main__":\n    so_km = float(input("Nhập quãng đường (km): "))\n    tien_xe = tinh_cuoc_chuyen_xe(so_km)\n    print(f"Quãng đường {so_km} km -> Giá cước: {tien_xe:,.0f} VNĐ")\n`,
      explanation: 'Bài toán tính cước luỹ tiến đa bậc là dạng bài tập kinh điển trong khoa học máy tính, rèn luyện cấu trúc rẽ nhánh chính xác.',
      sampleInput: '15\n',
      sampleOutput: 'Quãng đường 15.0 km -> Giá cước: 123,000 VNĐ\n',
    });
  }

  return pool.slice(0, 2).map(ensureVietnameseLessonQuality);
}

function analyzePythonCodeLocally(code: string) {
  const lines = code ? code.split('\n') : [];
  const imports: string[] = [];
  const functions: string[] = [];
  let hasLoops = false;
  let hasConditionals = false;
  let hasInput = false;
  let hasPrint = false;

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (line.startsWith('import ') || line.startsWith('from ')) {
      imports.push(line);
    }
    const defMatch = line.match(/^def\s+([a-zA-Z0-9_]+)\s*\(/);
    if (defMatch) {
      functions.push(defMatch[1]);
    }
    if (line.startsWith('for ') || line.startsWith('while ')) {
      hasLoops = true;
    }
    if (line.startsWith('if ') || line.startsWith('elif ') || line.startsWith('else:')) {
      hasConditionals = true;
    }
    if (line.includes('input(')) {
      hasInput = true;
    }
    if (line.includes('print(')) {
      hasPrint = true;
    }
  }

  return {
    linesCount: lines.length,
    imports,
    functions,
    hasLoops,
    hasConditionals,
    hasInput,
    hasPrint,
  };
}

// Local analyzer to detect exact error line, explain cause, and generate cleaner & shorter code
function analyzeAndFixLocally(code: string, errorText: string = ''): string {
  if (!code || !code.trim()) {
    return `🔍 **Phân tích mã nguồn:**\n- Chưa có mã nguồn trong Editor.\n\n⚡ **Mã mẫu chuẩn Python (PEP 8):**\n\`\`\`python\ndef main():\n    print("Hello, Pydroid 3!")\n\nif __name__ == "__main__":\n    main()\n\`\`\``;
  }

  const lines = code.split('\n');
  const fixedLines = [...lines];
  let errorLine = -1;
  let errorLineContent = '';
  let errorCause = '';
  let errorType = '';

  // Parse traceback if present
  if (errorText) {
    const lineMatch = errorText.match(/line (\d+)/i);
    if (lineMatch) {
      const parsedLine = parseInt(lineMatch[1], 10);
      if (parsedLine >= 1 && parsedLine <= lines.length) {
        errorLine = parsedLine;
        errorLineContent = lines[parsedLine - 1] || '';
      }
    }
    const typeMatch = errorText.match(/([A-Za-z]+Error|[A-Za-z]+Exception): (.*)/);
    if (typeMatch) {
      errorType = typeMatch[1];
      errorCause = `Thông báo lỗi từ hệ thống: ${typeMatch[2]}`;
    }
  }

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();
    const lineNum = i + 1;

    // 1. Missing colon on compound statement
    if (/^(if|elif|else|for|while|def|class|try|except|finally|with)\b/.test(trimmed) && !trimmed.endsWith(':') && !trimmed.includes('#')) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = `Thiếu dấu hai chấm ':' ở cuối câu lệnh \`${trimmed.split(' ')[0]}\`.`;
      }
      fixedLines[i] = rawLine + ':';
      continue;
    }

    // 2. Unbalanced parentheses (e.g. print("hello" or (a + b)
    const openParen = (rawLine.match(/\(/g) || []).length;
    const closeParen = (rawLine.match(/\)/g) || []).length;
    if (openParen > closeParen) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = `Thiếu ${openParen - closeParen} dấu đóng ngoặc tròn ')' trong câu lệnh.`;
      }
      fixedLines[i] = rawLine + ')'.repeat(openParen - closeParen);
      continue;
    }

    // 3. Unbalanced square brackets
    const openBracket = (rawLine.match(/\[/g) || []).length;
    const closeBracket = (rawLine.match(/\]/g) || []).length;
    if (openBracket > closeBracket) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = `Thiếu dấu đóng ngoặc vuông ']' cho danh sách (list).`;
      }
      fixedLines[i] = rawLine + ']'.repeat(openBracket - closeBracket);
      continue;
    }

    // 4. Invalid assignment in condition: if x = 5: -> if x == 5:
    if (/^(if|elif)\s+[^=><!]+=[^=].*$/.test(trimmed) && !/==/.test(trimmed)) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Phép so sánh trong câu lệnh điều kiện `if/elif` phải dùng toán tử `==` (hai dấu bằng), không được dùng phép gán `=`.';
      }
      fixedLines[i] = rawLine.replace(/=([^=])/, '==$1');
      continue;
    }

    // 5. Invalid constant assignment (e.g. 10 = x)
    if (/^[0-9]+(\.[0-9]+)?\s*=\s*/.test(trimmed)) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Không thể gán giá trị cho một hằng số số học (vế trái phép gán phải là tên biến).';
      }
      const parts = trimmed.split('=');
      if (parts.length === 2) {
        const val = parts[0].trim();
        const varName = parts[1].trim() || 'gia_tri';
        fixedLines[i] = rawLine.replace(trimmed, `${varName} = ${val}`);
      }
      continue;
    }

    // 6. Unclosed single or double quotes
    const singleQuotes = (trimmed.match(/'/g) || []).length;
    const doubleQuotes = (trimmed.match(/"/g) || []).length;
    if (singleQuotes % 2 !== 0 && !trimmed.includes('"""') && !trimmed.includes("'''")) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Chưa đóng dấu nháy đơn (\') cho chuỗi ký tự.';
      }
      fixedLines[i] = rawLine + "'";
      continue;
    }
    if (doubleQuotes % 2 !== 0 && !trimmed.includes('"""') && !trimmed.includes("'''")) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Chưa đóng dấu nháy kép (") cho chuỗi ký tự.';
      }
      fixedLines[i] = rawLine + '"';
      continue;
    }

    // 7. Python 2 style print statement
    if (/^print\s+["'].*$/.test(trimmed) && !trimmed.startsWith('print(')) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Trong Python 3, hàm `print()` bắt buộc phải có dấu ngoặc tròn bao quanh tham số: `print(...)`.';
      }
      const printArg = trimmed.replace(/^print\s+/, '');
      fixedLines[i] = rawLine.replace(trimmed, `print(${printArg})`);
      continue;
    }

    // 8. Misspelled print function (prnt / prin)
    if (/\b(prnt|prin)\s*\(/.test(trimmed)) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'NameError';
        errorCause = 'Sai chính tả tên hàm in xuất dữ liệu: sửa thành `print(...)`.';
      }
      fixedLines[i] = rawLine.replace(/\b(prnt|prin)\b/g, 'print');
      continue;
    }

    // 9. Zero division
    if (/\/ 0(?![0-9])/.test(trimmed) || /\/=\s*0(?![0-9])/.test(trimmed)) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'ZeroDivisionError';
        errorCause = 'Phép chia cho số 0 không hợp lệ trong toán học và Python.';
      }
      fixedLines[i] = rawLine.replace(/\/ 0(?![0-9])/, '/ 1  # Đã sửa tránh chia cho 0');
      continue;
    }

    // 10. Input without conversion before arithmetic
    if (trimmed.includes('input(') && !trimmed.includes('int(') && !trimmed.includes('float(')) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'Lưu ý Kiểu Dữ Liệu';
        errorCause = 'Hàm `input()` trả về chuỗi văn bản (str). Nếu dùng tính toán số học, cần ép kiểu `int(...)` hoặc `float(...)`.';
      }
      fixedLines[i] = rawLine.replace(/=\s*input\((.*)\)/, '= int(input($1))');
    }
  }

  if (errorLine === -1) {
    errorLine = 1;
    errorLineContent = lines[0] || '';
    errorType = 'Tối ưu hóa Code';
    errorCause = 'Kiểm tra toàn diện: Tối ưu thụt lề chuẩn PEP 8, làm sạch mã và đảm bảo luồng thực thi an toàn.';
  }

  const cleanCode = formatPep8Locally(fixedLines.join('\n'));

  return `🔍 **Phân tích lỗi mã nguồn:**
- 📍 **Vị trí lỗi:** **Dòng ${errorLine}**: \`${errorLineContent.trim() || '...'}\`
- ⚠️ **Loại lỗi:** \`${errorType || 'SyntaxError'}\`
- 💡 **Nguyên nhân & Cách sửa:** ${errorCause}

⚡ **Mã nguồn đã sửa hoàn chỉnh (Chuẩn Python PEP 8):**
\`\`\`python
${cleanCode.trim()}
\`\`\`

✨ **Điểm đã được sửa chữa & cải tiến:**
1. Khắc phục triệt để lỗi tại **Dòng ${errorLine}**, đảm bảo chương trình chạy trơn tru không bị dừng đột ngột.
2. Chuẩn hóa toàn bộ thụt lề 4 khoảng trắng và cách đặt tên theo chuẩn PEP 8.
3. Mã nguồn đã sẵn sàng: Nhấn nút **"Áp dụng vào Editor"** ngay trên khối code để cập nhật vào trình soạn thảo!`;
}

// Local PEP 8 Python code formatter
function formatPep8Locally(code: string): string {
  if (!code || !code.trim()) {
    return '# Chương trình Python chuẩn PEP 8\ndef main() -> None:\n    """Hàm khởi chạy chính của chương trình."""\n    print("Hello, Pydroid 3!")\n\nif __name__ == "__main__":\n    main()\n';
  }

  const lines = code.split('\n');
  const formattedLines: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const leadingWhitespace = line.match(/^\s*/)?.[0] || '';
    const numTabs = (leadingWhitespace.match(/\t/g) || []).length;
    const numSpaces = (leadingWhitespace.match(/ /g) || []).length;
    const indentLevel = Math.max(0, Math.floor((numTabs * 4 + numSpaces) / 4));
    const properIndent = '    '.repeat(indentLevel);
    const content = line.trim();

    if (!content) {
      formattedLines.push('');
      continue;
    }

    let formattedContent = content
      .replace(/,([^\s])/g, ', $1')
      .replace(/([^\s=!<>])=([^\s=])/g, '$1 = $2')
      .replace(/([^\s])\+([^\s])/g, '$1 + $2')
      .replace(/([^\s])\*([^\s*])/g, '$1 * $2');

    // Automatically append missing colon on compound statements
    if (/^(if|elif|else|for|while|def|class|try|except|finally|with)\b/.test(formattedContent) && !formattedContent.endsWith(':') && !formattedContent.includes('#')) {
      formattedContent += ':';
    }

    formattedLines.push(properIndent + formattedContent);
  }

  return formattedLines.join('\n').trim() + '\n';
}

// Generate comprehensive Vietnamese code explanation locally
function generateExplainResponseLocally(code: string): string {
  const analysis = analyzePythonCodeLocally(code);

  const importSection = analysis.imports.length > 0
    ? `  - **Thư viện sử dụng:** ${analysis.imports.map(i => `\`${i}\``).join(', ')}\n`
    : `  - **Thư viện:** Chỉ sử dụng các hàm built-in cơ bản của Python.\n`;

  const functionSection = analysis.functions.length > 0
    ? `  - **Hàm định nghĩa:** ${analysis.functions.map(f => `\`def ${f}()\``).join(', ')}\n`
    : `  - **Cấu trúc:** Thực thi tuần tự theo kịch bản script.\n`;

  const logicSection = [];
  if (analysis.hasInput) logicSection.push('nhận tương tác dữ liệu từ bàn phím qua `input()`');
  if (analysis.hasLoops) logicSection.push('sử dụng vòng lặp để xử lý dữ liệu');
  if (analysis.hasConditionals) logicSection.push('rẽ nhánh điều kiện logic (`if-elif-else`)');
  if (analysis.hasPrint) logicSection.push('xuất kết quả ra màn hình với `print()`');

  const notes = [
    'Tuân thủ quy tắc thụt lề 4 khoảng trắng chuẩn PEP 8 cho các khối lệnh.',
    'Đặt tên biến và hàm theo phong cách `snake_case` (ví dụ: `my_variable`, `tinh_tong`).',
  ];
  if (analysis.hasInput) {
    notes.push('Dữ liệu từ `input()` luôn là kiểu chuỗi `str`, cần ép kiểu `int()` hoặc `float()` khi tính toán số học.');
  }
  if (analysis.hasLoops) {
    notes.push('Đảm bảo điều kiện dừng trong vòng lặp để tránh hiện tượng vòng lặp vô tận (infinite loop).');
  }

  return `📖 **Giải thích chi tiết mã nguồn Python:**

### 1. 🎯 Tổng quan & Mục đích
- Chương trình gồm **${analysis.linesCount} dòng mã**.
${importSection}${functionSection}- **Luồng xử lý chính:** ${logicSection.length > 0 ? logicSection.join(', ') : 'Xử lý các biểu thức logic cơ bản'}.

### 2. ⚡ Luồng thực thi (Execution Flow)
1. **Khởi tạo:** Trình thông dịch Python nạp mã từ dòng đầu tiên, khai báo các thư viện và định nghĩa hàm (nếu có).
2. **Xử lý:** ${analysis.hasInput ? 'Chờ người dùng nhập dữ liệu qua console, sau đó ' : ''}tính toán và xử lý tuần tự qua từng khối lệnh.
3. **Kết thúc:** ${analysis.hasPrint ? 'In kết quả hoàn tất ra màn hình Terminal.' : 'Hoàn tất kịch bản với mã thoát 0 (Exit Code 0).' }

### 3. ⚠️ Các điểm cần lưu ý
${notes.map(n => `- ${n}`).join('\n')}

💡 *Gợi ý: Bạn có thể nhấn nút **"Tối ưu PEP 8"** kế bên để chuẩn hóa toàn bộ code ngay lập tức, hoặc đặt bất kỳ câu hỏi nào trong ô chat bên dưới!*`;
}


export { ensureVietnameseLessonQuality, getFallbackLessons, analyzeAndFixLocally, formatPep8Locally, generateExplainResponseLocally };
