// Lớp thay thế máy chủ cho bản APK: chặn các lệnh gọi /api/... và xử lý ngay trên điện thoại.
import {
  analyzeAndFixLocally,
  ensureVietnameseLessonQuality,
  formatPep8Locally,
  generateExplainResponseLocally,
  getFallbackLessons,
} from './localAi';
import { pipInstall, pipList, pipSearch, pipUninstall } from './pip';

export const GEMINI_KEY_STORAGE = 'pydroid_gemini_key';
const CANDIDATE_MODELS = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
const PYODIDE_CORE_FILES = [
  'pyodide.js', 'pyodide.mjs', 'pyodide.asm.js', 'pyodide.asm.wasm',
  'python_stdlib.zip', 'pyodide-lock.json',
];
const PYODIDE_CDN = 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/';

const realFetch: typeof window.fetch = window.fetch.bind(window);

function getKey(): string {
  try {
    return (localStorage.getItem(GEMINI_KEY_STORAGE) || '').trim();
  } catch (_) {
    return '';
  }
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

async function callGemini(body: any, timeoutMs = 45000): Promise<string> {
  const key = getKey();
  if (!key) throw new Error('NO_KEY');
  let lastErr: any = null;
  for (const model of CANDIDATE_MODELS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await realFetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
          body: JSON.stringify(body),
          signal: controller.signal,
        }
      );
      if (!res.ok) throw new Error(`Gemini ${model} trả mã ${res.status}`);
      const data = await res.json();
      const parts = data?.candidates?.[0]?.content?.parts;
      const text = Array.isArray(parts) ? parts.map((p: any) => p?.text || '').join('') : '';
      if (!text) throw new Error('Phản hồi rỗng');
      return text;
    } catch (e) {
      lastErr = e;
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastErr || new Error('Gemini lỗi');
}

const S = (description?: string) => ({ type: 'STRING', ...(description ? { description } : {}) });

async function handleDebug(payload: any): Promise<Response> {
  const code = payload?.code || '';
  const errorText = payload?.errorText || '';
  if (!code && !errorText) return jsonResponse({ error: 'Thiếu thông tin mã hoặc lỗi' }, 400);

  try {
    const prompt = `Bạn là Trình gỡ lỗi Python AI thông minh hàng đầu trên ứng dụng Pydroid 3 Android.
Người dùng đang viết mã Python và gặp lỗi hoặc yêu cầu kiểm tra sửa lỗi sau:

=== MÃ PYTHON HIỆN TẠI ===
${code}

=== THÔNG BÁO LỖI / TRACEBACK ===
${errorText || '(Phân tích toàn bộ cú pháp, phát hiện lỗi cú pháp, thụt lề, chia cho 0 hoặc lỗi runtime và sửa lỗi chuẩn PEP 8)'}

Nhiệm vụ của bạn:
1. Nhận diện chính xác tên loại lỗi (SyntaxError, IndentationError, ZeroDivisionError, NameError, TypeError...).
2. Giải thích nguyên nhân gốc rễ bằng tiếng Việt ngắn gọn, thân thiện, dễ hiểu cho người học lập trình trên điện thoại.
3. Đưa ra danh sách các mẹo khắc phục và quy tắc PEP 8 liên quan.
4. Cung cấp phiên bản mã Python ĐÃ ĐƯỢC SỬA HOÀN CHỈNH, chuẩn PEP 8, không làm thay đổi ý đồ thuật toán.
5. Tóm tắt nhanh các thay đổi quan trọng đã sửa.

Hãy trả về phản hồi ĐÚNG định dạng JSON theo schema đã cho.`;
    const text = await callGemini({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: 'OBJECT',
          properties: {
            errorType: S(), vietnameseSummary: S(), rootCause: S(),
            tips: { type: 'ARRAY', items: S() },
            fixedCode: S(), diffExplanation: S(),
          },
          required: ['errorType', 'vietnameseSummary', 'rootCause', 'tips', 'fixedCode', 'diffExplanation'],
        },
      },
    });
    const parsed = JSON.parse(text);
    if (parsed.errorType && parsed.fixedCode) return jsonResponse(parsed);
  } catch (_) {
    // rơi xuống bộ phân tích cục bộ
  }

  const local = analyzeAndFixLocally(code, errorText);
  const m = local.match(/```python\s*([\s\S]*?)```/);
  const fixedCode = m && m[1] ? m[1].trim() : formatPep8Locally(code);
  const errStr = String(errorText || '');
  const em = errStr.match(/([A-Za-z]+Error|[A-Za-z]+Exception): (.*)/);
  const type = em ? em[1] : 'SyntaxError';
  const detail = em ? em[2] : errStr.slice(0, 100) || 'Lỗi cú pháp hoặc runtime';
  const noKey = getKey() ? '' : ' (Chưa nhập khóa Gemini nên dùng bộ phân tích cục bộ - xem Cài đặt.)';
  return jsonResponse({
    errorType: type,
    vietnameseSummary: `Phát hiện lỗi ${type}: ${detail}${noKey}`,
    rootCause: `Chương trình gặp vấn đề trong quá trình thực thi: ${detail}. Đã tự động phân tích và khắc phục chuẩn PEP 8.`,
    tips: [
      'Kiểm tra kỹ cú pháp và thụt lề 4 khoảng trắng chuẩn PEP 8.',
      'Sử dụng khối try...except để bao bọc các thao tác có khả năng gây lỗi.',
      'Đảm bảo các biến đã được khai báo trước khi sử dụng.',
    ],
    fixedCode,
    diffExplanation: 'Đã chuẩn hóa mã theo PEP 8.',
  });
}

async function handleLessons(payload: any): Promise<Response> {
  const topic = typeof payload?.topic === 'string' && payload.topic.trim() ? payload.topic.trim() : 'Python ứng dụng thực tế';
  const level = payload?.level || 'cơ bản';
  const existing: string[] = Array.isArray(payload?.existingTitles) ? payload.existingTitles.filter(Boolean) : [];

  try {
    const prompt = `Bạn là Giảng viên Chuyên gia Lập trình Python cho ứng dụng Pydroid 3 Web trên Android.
Hãy tạo 2 đến 3 bài tập thực hành Python HOÀN TOÀN MỚI theo chủ đề: "${topic}" và cấp độ: "${level}".

Các bài đã có (KHÔNG được trùng lặp):
${existing.length ? existing.slice(-30).map((t) => `- ${t}`).join('\n') : '(Kho bài đang trống)'}

Quy tắc:
- Tình huống gần gũi đời sống (tính tiền quán trà sữa, quản lý chi tiêu, xếp loại học lực...).
- 100% tên biến, hàm, tham số trong starterCode và solutionCode bằng tiếng Việt không dấu dạng snake_case (không dùng x, y, i, n, data, result, total...). Chú thích và chuỗi in ra bằng tiếng Việt.

Mỗi bài gồm: id (snake_case, bắt đầu bằng lesson_ai_), title, level ('basic' | 'intermediate' | 'advanced'), description, starterCode (có # TODO), solutionCode (chuẩn PEP 8), explanation, sampleInput, sampleOutput.
Xuất kết quả tiếng Việt theo định dạng JSON.`;
    const text = await callGemini({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: 'OBJECT',
          properties: {
            lessons: {
              type: 'ARRAY',
              items: {
                type: 'OBJECT',
                properties: {
                  id: S(), title: S(), level: S(), description: S(), starterCode: S(),
                  solutionCode: S(), explanation: S(), sampleInput: S(), sampleOutput: S(),
                },
                required: ['id', 'title', 'level', 'description', 'starterCode', 'solutionCode', 'explanation'],
              },
            },
          },
          required: ['lessons'],
        },
      },
    });
    const parsed = JSON.parse(text);
    if (Array.isArray(parsed.lessons) && parsed.lessons.length > 0) {
      return jsonResponse({ lessons: parsed.lessons.map(ensureVietnameseLessonQuality) });
    }
  } catch (_) {
    // dùng kho bài dự phòng
  }
  return jsonResponse({ lessons: getFallbackLessons(topic, level, existing) });
}

const FIX_RE = /s[uư][aảã].*l[oô][iỉĩ]|l[oô][iỉĩ]|fix.*error|fix.*bug|debug|g[oỡ].*l[oô][iỉĩ]|b[iị].*l[oô][iỉĩ]|d[oò]ng.*m[aấ]y.*l[oô][iỉĩ]|s[uư][aảã].*code/i;

function localChatReply(instruction: string, code: string, errorText: string, isFix: boolean): string {
  if (isFix) return analyzeAndFixLocally(code, errorText);
  switch (instruction) {
    case 'explain_source_code':
    case 'initial_explain':
      return generateExplainResponseLocally(code);
    case 'optimize_pep8':
    case 'pythonic':
      return `⚡ **Mã đã chuẩn hóa PEP 8:**\n\n\`\`\`python\n${formatPep8Locally(code)}\n\`\`\``;
    case 'try_except':
      return `🛡️ **Bổ sung try...except:**\n\n\`\`\`python\ntry:\n${(code || 'pass').split('\n').map((l) => '    ' + l).join('\n')}\nexcept Exception as e:\n    print(f"❌ Xảy ra lỗi: {e}")\n\`\`\``;
    default:
      return analyzeAndFixLocally(code, errorText);
  }
}

async function handleChat(payload: any): Promise<Response> {
  const code: string = payload?.code || '';
  const messages: any[] = Array.isArray(payload?.messages) ? payload.messages : [];
  const instruction: string = payload?.instruction || '';
  const errorText: string = payload?.errorText || '';
  const last = messages[messages.length - 1];
  const isFix = instruction === 'fix_error' || instruction === 'analyze_fix_clean' || FIX_RE.test(String(last?.text || '').toLowerCase());

  try {
    const numbered = code.split('\n').map((l, i) => `${i + 1}: ${l}`).join('\n');
    const system = `Bạn là Trợ lý AI Lập trình Python thông minh, tận tâm trên ứng dụng Pydroid 3 Web cho Android.
Luôn trả lời bằng tiếng Việt thân thiện, rõ ràng. Tuân thủ PEP 8.
Mã hiện tại trong Editor (kèm số dòng):
\`\`\`python
${numbered || '# (Chưa có mã nguồn)'}
\`\`\`
${errorText ? `Lỗi gần nhất từ Terminal:\n\`\`\`\n${errorText}\n\`\`\`\n` : ''}
Khi đưa mã hoàn chỉnh, bọc trong khối \`\`\`python ... \`\`\` (không kèm số dòng) để giao diện có nút "Áp dụng vào Editor".
Khi sửa lỗi: nêu rõ lỗi ở dòng số mấy, nguyên nhân, mã đã sửa hoàn chỉnh và các điểm cải tiến.`;

    let userPrompt = last?.text || 'Hãy phân tích mã nguồn hiện tại của mình.';
    if (isFix && !(last?.text && last.text.length > 5)) {
      userPrompt = 'Hãy phân tích lỗi trong mã hiện tại: lỗi ở dòng nào, nguyên nhân, và viết mã đã sửa hoàn chỉnh theo PEP 8.';
    }
    const history = messages.slice(0, -1).map((m) => ({
      role: m.sender === 'user' ? 'user' : 'model',
      parts: [{ text: String(m.text || '') }],
    }));
    const text = await callGemini({
      systemInstruction: { parts: [{ text: system }] },
      contents: [...history, { role: 'user', parts: [{ text: userPrompt }] }],
    });
    return jsonResponse({ reply: text });
  } catch (e: any) {
    const hint = getKey()
      ? ''
      : '\n\n🔑 *Chưa có khóa Gemini nên đang dùng bộ phân tích cục bộ. Nhập khóa trong Cài đặt để dùng AI đầy đủ.*';
    return jsonResponse({ reply: localChatReply(instruction, code, errorText, isFix) + hint });
  }
}

async function handleApi(url: URL, init?: RequestInit): Promise<Response> {
  const path = url.pathname;
  let payload: any = {};
  try {
    if (init?.body && typeof init.body === 'string') payload = JSON.parse(init.body);
  } catch (_) {}

  if (path === '/api/ai/debug') return handleDebug(payload);
  if (path === '/api/ai/generate-lessons') return handleLessons(payload);
  if (path === '/api/ai/chat') return handleChat(payload);
  if (path === '/api/python/version') {
    return jsonResponse({
      cpython: { version: 'N/A', details: 'CPython Native không có trong bản APK' },
      pyodide: { version: '3.12.1', details: 'Pyodide 0.26.4 (Python 3.12.1)' },
    });
  }
  if (path === '/api/python/packages') return jsonResponse({ packages: await pipList() });
  if (path === '/api/python/packages/search') {
    return jsonResponse({ packages: await pipSearch(url.searchParams.get('q') || '') });
  }
  if (path === '/api/python/packages/install') {
    return jsonResponse(await pipInstall(String(payload?.name || ''), !!payload?.upgrade));
  }
  if (path === '/api/python/packages/uninstall') {
    return jsonResponse(await pipUninstall(String(payload?.name || '')));
  }
  // /api/python/lint và các đường dẫn khác: để ứng dụng tự dùng bộ kiểm tra phía máy khách
  return jsonResponse({ error: 'Không có máy chủ trong bản APK' }, 503);
}

function toUrl(input: RequestInfo | URL): URL | null {
  try {
    const raw = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    return new URL(raw, window.location.href);
  } catch (_) {
    return null;
  }
}

window.fetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
  const url = toUrl(input);
  if (url && url.origin === window.location.origin) {
    if (url.pathname.startsWith('/api/')) {
      return handleApi(url, init);
    }
    // Gói mở rộng của Pyodide (numpy, pandas...) không nằm trong APK: tải từ CDN
    if (url.pathname.startsWith('/pyodide/')) {
      const file = url.pathname.slice('/pyodide/'.length);
      if (file && !PYODIDE_CORE_FILES.includes(file)) {
        return realFetch(PYODIDE_CDN + file, init);
      }
    }
  }
  return realFetch(input as any, init);
};
